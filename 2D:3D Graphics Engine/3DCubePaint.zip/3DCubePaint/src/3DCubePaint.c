/*
=======================================================================================
 Name        : DrawLine.c
 Author      : Akansha Jajodia
 Version     : 1.0
 Copyright   : $(copyright)
 Description : Display 3Dcube with diffuse reflection and initial letter on top surface
=======================================================================================
*/

#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "LPC17xx.h"                        /* LPC17xx definitions */
#include "ssp.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <time.h>


/* Be careful with the port number and location number, because

some of the location may not exist in that port. */

#define PORT_NUM            0


uint8_t src_addr[SSP_BUFSIZE];
uint8_t dest_addr[SSP_BUFSIZE];


#define ST7735_TFTWIDTH 127
#define ST7735_TFTHEIGHT 159

#define ST7735_CASET 0x2A
#define ST7735_RASET 0x2B
#define ST7735_RAMWR 0x2C
#define ST7735_SLPOUT 0x11
#define ST7735_DISPON 0x29
#define pi 3.14


#define swap(x, y) {x = x + y; y = x - y; x = x - y ;}

// defining color values

#define LIGHTBLUE 0x00FFE0
#define GREEN 0x00FF00
#define DARKBLUE 0x000033
#define BLACK 0x000000
#define BLUE 0x0007FF
#define RED 0xFF0000
#define MAGENTA 0x00F81F
#define WHITE 0xFFFFFF
#define PURPLE 0xCC33FF
#define PINK 0xFFC0CB
#define YELLOW 0xFFFF00
#define SILVER 0xC0C0C0
#define LIME 0x00FF00
#define ORANGE 0xFFA500
#define MAROON 0x800000
#define FOREST 0x228B22
#define DARKGREEN 0x006400
#define LIGHTGREEN 0X90EE90
#define SEAGREEN 0X2E8B57
#define ORANGERED 0XFF4500
#define GOLD 0XFFD700
#define GRAY 0X808080
#define SHADOW 0X8A795D

#define pi 3.14
#define alpha pi/6


int _height = ST7735_TFTHEIGHT;
int _width = ST7735_TFTWIDTH;


void spiwrite(uint8_t c)

{

 int pnum = 1;

 src_addr[0] = c;

 SSP_SSELToggle( pnum, 0 );

 SSPSend( pnum, (uint8_t *)src_addr, 1 );

 SSP_SSELToggle( pnum, 1 );

}



void writecommand(uint8_t c)

{

 LPC_GPIO0->FIOCLR |= (0x1<<21);

 spiwrite(c);

}



void writedata(uint8_t c)

{

 LPC_GPIO0->FIOSET |= (0x1<<21);

 spiwrite(c);

}



void writeword(uint16_t c)

{

 uint8_t d;

 d = c >> 8;

 writedata(d);

 d = c & 0xFF;

 writedata(d);

}



void write888(uint32_t color, uint32_t repeat)

{

 uint8_t red, green, blue;

 int i;

 red = (color >> 16);

 green = (color >> 8) & 0xFF;

 blue = color & 0xFF;

 for (i = 0; i< repeat; i++) {

  writedata(red);

  writedata(green);

  writedata(blue);

 }

}



void setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)

{

 writecommand(ST7735_CASET);

 writeword(x0);

 writeword(x1);

 writecommand(ST7735_RASET);

 writeword(y0);

 writeword(y1);

}


void fillrect(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

 //int16_t i;

 int16_t width, height;

 width = x1-x0+1;

 height = y1-y0+1;

 setAddrWindow(x0,y0,x1,y1);

 writecommand(ST7735_RAMWR);

 write888(color,width*height);

}



void lcddelay(int ms)

{

 int count = 24000;

 int i;

 for ( i = count*ms; i--; i > 0);

}



void lcd_init()

{

 int i;
 printf("LCD Demo Begins!!!\n");
 // Set pins P0.16, P0.21, P0.22 as output
 LPC_GPIO0->FIODIR |= (0x1<<16);

 LPC_GPIO0->FIODIR |= (0x1<<21);

 LPC_GPIO0->FIODIR |= (0x1<<22);

 // Hardware Reset Sequence
 LPC_GPIO0->FIOSET |= (0x1<<22);
 lcddelay(500);

 LPC_GPIO0->FIOCLR |= (0x1<<22);
 lcddelay(500);

 LPC_GPIO0->FIOSET |= (0x1<<22);
 lcddelay(500);

 // initialize buffers
 for ( i = 0; i < SSP_BUFSIZE; i++ )
 {

   src_addr[i] = 0;
   dest_addr[i] = 0;
 }

 // Take LCD display out of sleep mode
 writecommand(ST7735_SLPOUT);
 lcddelay(200);

 // Turn LCD display on
 writecommand(ST7735_DISPON);
 lcddelay(200);

}




void drawPixel(int16_t x, int16_t y, uint32_t color)

{

 if ((x < 0) || (x >= _width) || (y < 0) || (y >= _height))

 return;

 setAddrWindow(x, y, x + 1, y + 1);

 writecommand(ST7735_RAMWR);

 write888(color, 1);

}

/*****************************************************************************
** Descriptions:        Draw line function
** parameters:           Starting point (x0,y0), Ending point(x1,y1) and color
** Returned value:        None
*****************************************************************************/


void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color)

{

 int16_t slope = abs(y1 - y0) > abs(x1 - x0);

 if (slope) {

  swap(x0, y0);

  swap(x1, y1);

 }

 if (x0 > x1) {

  swap(x0, x1);

  swap(y0, y1);

 }

 int16_t dx, dy;

 dx = x1 - x0;

 dy = abs(y1 - y0);

 int16_t err = dx / 2;

 int16_t ystep;

 if (y0 < y1) {

  ystep = 1;

 }

 else {

  ystep = -1;

 }

 for (; x0 <= x1; x0++) {

  if (slope) {

   drawPixel(y0, x0, color);

  }

  else {

   drawPixel(x0, y0, color);

  }

  err -= dy;

  if (err < 0) {

   y0 += ystep;

   err += dx;

  }

 }

}


//Define 2d Point struct
//Define 2d Point struct
struct Point
{
	int x;
	int y;

};

//Physical to virtual
int v2p_x(int x)
{
return x+_width/2;
}
int v2p_y(int y)
{
return -y+_height/2;
}

//find branch point

//Define 3d Point structure
struct Point_3D
{
	float x;
	float y;
	float z;
};

//define eye location
	float_t xe = 350;
	float_t ye = 350;
	float_t ze = 350;

	 int elev = 10;

int round(float number)
{
	return (number >= 0) ? (int)(number + 0.5) : (int)(number - 0.5);
}

// To convert world to viewer coordinates
struct Point Transformation_pipeline (struct Point_3D world)
{
	struct Point perspective;
	struct Point_3D viewer;
	//define distance
	float_t Rho = sqrt(pow(xe,2)+pow(ye,2)+pow(ze,2));
	float_t D_focal = 260;

	//sin and cos pheta
	float spheta = ye / sqrt(pow(xe,2)+pow(ye,2));
	float cpheta = xe / sqrt(pow(xe,2)+pow(ye,2));
	//second angle
	float sphi = sqrt(pow(xe,2)+pow(ye,2))/Rho;
	float cphi = ze / Rho;

	viewer.x = -spheta*world.x+cpheta*world.y;
	viewer.y = -cpheta*cphi*world.x-cphi*spheta*world.y+sphi*world.z;
	viewer.z = -sphi*cpheta*world.x-sphi*cpheta*world.y-cpheta*world.z+Rho;

	perspective.x = round(D_focal*viewer.x/viewer.z);
	perspective.y = round(D_focal*viewer.y/viewer.z);

	perspective.x = v2p_x(perspective.x);
	perspective.y = v2p_y(perspective.y);

	return perspective;
}


float diff_reflection(struct Point_3D Pi)
{
	//--------compute distance------------------*
		struct Point_3D Ps = {-50, 50, 360};

	    float red;
	    float scaling = 30000, shift = 0.2;
	    float distanceSqr = (pow((Ps.x - Pi.x), 2)+ pow((Ps.y - Pi.y), 2) + pow((Ps.z - Pi.z), 2));
	    float cosine  = ((Ps.z -Pi.z)/sqrt(distanceSqr));
	    float temp  =  cosine /   distanceSqr;
	    temp =  (scaling * temp);
	    temp = (temp < shift) ? shift : temp;
	    red = (255 * 0.8 * temp);
	    return red;

}

void fillshadow(struct Point_3D startPt,struct Point_3D endPt)
{

		struct Point_3D temp;
		struct Point currPt;
		for(float i=startPt.y; i<endPt.y; i++)
		{
		for(float j=startPt.x; j<endPt.x; j++)
		{
		temp.x = j;
		temp.y = i;
		temp.z = 0;

		currPt = Transformation_pipeline(temp);
		drawPixel(currPt.x, currPt.y,DARKBLUE); //SHADOW);
		}
		}
}

void fillside(struct Point_3D startPt,struct Point_3D endPt,int size, int side)
{

	struct Point_3D temp;
	struct Point currPt;
	if(side==1)
	{
		for(float i=startPt.z; i<endPt.z; i++)
		{
			for(float j=startPt.y; j<endPt.y; j++)
			{
				temp.x = size;
				temp.y = j;
				temp.z = i;
				currPt = Transformation_pipeline(temp);
				drawPixel(currPt.x, currPt.y,SILVER);
			}
		}
	}
	else if(side == 2)
	{
		for(float i=startPt.z; i<endPt.z; i++)
		{
			for(float j=startPt.x; j<endPt.x; j++)
			{
				temp.x = j;
				temp.y = size;
				temp.z = i;
				currPt = Transformation_pipeline(temp);
				drawPixel(currPt.x, currPt.y,SILVER);
			}
		}
	}

	else if(side == 3)
		{
		uint32_t color;
		float r=0,g=0,b=0;
			for(float i=startPt.y; i<endPt.y; i++)
			{
				for(float j=startPt.x; j<endPt.x; j++)
				{
					temp.x = j;
					temp.y = i;
					temp.z = size+elev;
					r = 0;
					g = diff_reflection(temp);
				    b =  0;
				    color =(((uint32_t)round(r)) << 16) +(((uint32_t)g) << 8) + ((uint32_t)b);
					currPt = Transformation_pipeline(temp);
					drawPixel(currPt.x, currPt.y,color);
				}
			}
		}

}

uint32_t findcolor(float x, float y,float Idiff1,float Idiff2,struct Point p1,struct Point p2)
{
	float newx,newy,ncolor;
	uint32_t color;
	float red,blue;

	newx = Idiff1 + (Idiff2 - Idiff1)*(x - p1.x)/(p2.x-p1.x);
	newy = Idiff1 + (Idiff2 - Idiff1)*(y - p1.y)/(p2.y-p1.y);
	ncolor = (newx +  newy)/2.0;
	red = 0;
	blue =  0;
	color =(((uint32_t)red) << 16) +(((uint32_t)round(ncolor)) << 8) + ((uint32_t)blue);

	return color;

}

//DDA Function for line generation
void DDA_line(struct Point p1, struct Point p2, float Idiff1,float Idiff2)
{
	uint32_t color;
    // calculate dx & dy
    int dx = p2.x - p1.x;
    int dy = p2.y - p1.y;

    // calculate steps required for generating pixels
    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

    // calculate increment in x & y for each steps
    float Xinc = dx / (float) steps;
    float Yinc = dy / (float) steps;

    // Put pixel for each step
    float X = p1.x;
    float Y = p1.y;
    for (int i = 0; i < steps; i++)
    {
    	color = findcolor(X,Y,Idiff1,Idiff2,p1,p2);
        drawPixel(X,Y,color);
        X += Xinc;           // increment in x at each step
        Y += Yinc;           // increment in y at each step

    }

}

// To draw a 3D cube
void draw3dcube(int cube_size)
{
	struct Point c1,c2,c3,c4,c5,c6,c7;
	int pt = 0;
	struct Point_3D cu_dim = {pt,pt,(cube_size+pt+elev)};//(0,0,100)
	float Idiff1,Idiff2,Idiff3,Idiff4;
	struct Point_3D t1,t2,t3,t4,t5,t6,t7;
	t1 = cu_dim;
	Idiff1 = diff_reflection(t1);
	c1 = Transformation_pipeline(cu_dim);

	cu_dim.x = (cube_size+pt);//(100,0,100)
	t2 = cu_dim;
	Idiff2 = diff_reflection(t2);
	c2 = Transformation_pipeline(cu_dim);

	cu_dim.y = (cube_size+pt);//(100,100,100)
	t3 = cu_dim;
	Idiff3 = diff_reflection(t3);
	c3 = Transformation_pipeline(cu_dim);

	cu_dim.x = pt;//(0,100,100)
	t4 = cu_dim;
	Idiff4 = diff_reflection(t4);
	c4 = Transformation_pipeline(cu_dim);

	cu_dim.x= (cube_size+pt);//(100,0,0)
	cu_dim.y = pt;
	cu_dim.z = pt+elev;
	t5 = cu_dim;
	c5 = Transformation_pipeline(cu_dim);

	cu_dim.y = (cube_size+pt);//(100,100,0)
	t6 = cu_dim;
	c6 = Transformation_pipeline (cu_dim);

	cu_dim.x = pt;//(0,100,0)
	t7 = cu_dim;
	c7 = Transformation_pipeline (cu_dim);

	DDA_line(c1,c2,Idiff1,Idiff2);
	DDA_line(c2,c3,Idiff2,Idiff3);
	DDA_line(c3,c4,Idiff3,Idiff4);
	DDA_line(c4,c1,Idiff4,Idiff1);

	lcddelay(300);

	drawLine(c2.x, c2.y, c5.x, c5.y,SILVER);
	drawLine(c5.x, c5.y, c6.x, c6.y,SILVER);
	drawLine(c6.x, c6.y, c3.x, c3.y,SILVER);
	drawLine(c6.x, c6.y, c7.x, c7.y,SILVER);
	drawLine(c7.x, c7.y, c4.x, c4.y,SILVER);

	fillside(t5,t3,cube_size,1);//Left fill
	fillside(t7,t3,cube_size,2);//right fill
	fillside(t1,t3,cube_size,3);//top surface

}

//Calculate lambda values for cube
float lambda_calc(float zi,float zs)
{
	return -zi/(zs-zi);
}

void draw3DAxes()
{
	int width = ST7735_TFTWIDTH/2;
	int height = ST7735_TFTHEIGHT/2;

	struct Point_3D world[4],viewer[4];
	//pointViewer viewer;
	struct Point perspective[4];

	int Xe = 90.00;
	int Ye = 90.00;
	int Ze = 90.00;

	double Rho = sqrt(pow(Xe,2) + pow(Ye,2) + pow(Ze,2));
	int dFocal = 40.0;

	world[0].x = 0.0;
	world[0].y = 0.0;
	world[0].z = 0.0;

	world[1].x = 200.0;
	world[1].y = 0.0;
	world[1].z = 0.0;

	world[2].x = 0.0;
	world[2].y = 200.0;
	world[2].z = 0.0;

	world[3].x = 0.0;
	world[3].y = 0.0;
	world[3].z = 200.0;

	double cTheta = acos(Xe/sqrt(pow(Xe,2)+pow(Ye,2)));
	double cPhi = acos(Ze/Rho);

	for(int i =0;i <= 3; i++)
	{
		viewer[i].x = (world[i].y * cos(cTheta))-(world[i].x * sin(cTheta));
		viewer[i].y = (world[i].z*sin(cPhi))-(world[i].x*cos(cTheta)*cos(cPhi))-(world[i].y*cos(cPhi)*sin(cTheta));
		viewer[i].z = Rho-(world[i].y*sin(cPhi)*cos(cTheta))-(world[i].x*sin(cPhi)*cos(cTheta))-(world[i].z*cos(cPhi));
	}


	for(int i=0; i<=3;i++)
	{
		perspective[i].x = dFocal * viewer[i].x / viewer[i].z;
		perspective[i].y = dFocal * viewer[i].y / viewer[i].z;
		perspective[i].x = width + perspective[i].x;
		perspective[i].y = height - perspective[i].y;
	}
	drawLine(perspective[0].x,perspective[0].y,perspective[1].x,perspective[1].y,DARKGREEN);
	drawLine(perspective[0].x,perspective[0].y,perspective[2].x,perspective[2].y,DARKGREEN);
	drawLine(perspective[0].x,perspective[0].y,perspective[3].x,perspective[3].y,DARKGREEN);
}


// To draw shadow for cube
void DrawShadow(double cube_size, struct Point_3D ps)
{
	float l1,l2,l3,l4;
	struct Point s1,s2,s3,s4,ps_p;
	struct Point_3D xp1,xp2,xp3,xp4;
	int pt = 0;
	struct Point_3D p1 = {pt,pt,(cube_size+pt+elev)};//p1
	struct Point_3D p2 = {(cube_size+pt),pt,(cube_size+pt+elev)};//p2
	struct Point_3D p3 = {(cube_size+pt),(cube_size+pt),(cube_size+pt+elev)};//p4
	struct Point_3D p4 = {pt,(cube_size+pt),(cube_size+pt+elev)};//p3
	ps_p = Transformation_pipeline(ps);
	l1 = lambda_calc(p1.z,ps.z);
	l2 = lambda_calc(p2.z,ps.z);
	l3 = lambda_calc(p3.z,ps.z);
	l4 = lambda_calc(p4.z,ps.z);

	/*printf("\nLambda 1 %0.2f:",l1);
	printf("\nLambda 2 %0.2f:",l2);
	printf("\nLambda 3 %0.2f:",l3);
	printf("\nLambda 4 %0.2f:",l4);*/

	xp1.x = p1.x + l1*(ps.x - p1.x);
	xp1.y = p1.y + l1*(ps.y - p1.y);
	xp1.z = p1.z + l1*(ps.z - p1.z);


	xp2.x = p2.x + l2*(ps.x - p2.x);
	xp2.y = p2.y + l2*(ps.y - p2.y);
	xp2.z = p2.z + l2*(ps.z - p2.z);


	xp3.x = p3.x + l3*(ps.x - p3.x);
	xp3.y = p3.y + l3*(ps.y - p3.y);
	xp3.z = p3.z + l3*(ps.z - p3.z);


	xp4.x = p4.x + l4*(ps.x - p4.x);
	xp4.y = p4.y + l4*(ps.y - p4.y);
	xp4.z = p4.z + l4*(ps.z - p4.z);



	s1 = Transformation_pipeline (xp1);
	s2 = Transformation_pipeline (xp2);
	s3 = Transformation_pipeline (xp3);
	s4 = Transformation_pipeline (xp4);

	drawLine(s1.x,s1.y,s2.x,s2.y,GRAY);
	drawLine(s2.x,s2.y,s3.x,s3.y,GRAY);
	drawLine(s3.x,s3.y,s4.x,s4.y,GRAY);
	drawLine(s4.x,s4.y,s1.x,s1.y,GRAY);


	fillshadow(xp1,xp3);
}

void draw_A(int start_pnt, int size)
{
	struct Point_3D temp;
	struct Point p1;
	int i,j;
	size=size+start_pnt;
	int map[80][80];

	for(i = 0; i < 80;i++)
	{
		for(j = 0; j < 80;j++)
		{
			if(i>=10 && i<=12 && j>=7 && j<=60){
							map[i][j]=1;
			}else if(i>=10 && i<=42 && j>=29 && j<=32){
							map[i][j]=1;
			}else if(i>=10 && i<=42 && j>=7 && j<=10){
				            map[i][j]=1;
			}else if(i>=38 && i<=40 && j>=7 && j<=60){
							map[i][j]=1;
			//}else if(i>=17 && i<=22 && j>=10 && j<=48){

			}else{
							map[i][j]=0;
			}
		}
	}

	for(i=0;i<80;i++)
	{
		for(j=0;j<80;j++)
		{
			if(map[i][j]==1)
			{
				temp.x = i;
				temp.y = j;
				temp.z = size;
				p1 = Transformation_pipeline(temp);
				drawPixel(p1.x,p1.y,SILVER);
			}
		}
	}
}





//Main function
int main (void)
{
	uint32_t pnum = PORT_NUM;
	int start_pnt = 0;
	int size = 100;
	double x[8] = {start_pnt,(start_pnt+size),(start_pnt+size),start_pnt,start_pnt,(start_pnt+size),(start_pnt+size),start_pnt};
	double y[8] = {start_pnt, start_pnt, start_pnt+size, start_pnt+size, start_pnt, start_pnt, (start_pnt+size), (start_pnt+size) };
	double z[8] = {start_pnt, start_pnt, start_pnt, start_pnt, (start_pnt+size), (start_pnt+size), (start_pnt+size), (start_pnt+size)};

	pnum = 1 ;

	if ( pnum == 1 )
		SSP1Init();

	else
		puts("Port number is not correct");

	lcd_init();

	fillrect(0, 0, ST7735_TFTWIDTH, ST7735_TFTHEIGHT, WHITE);

    struct Point_3D pl_source = {-50, 50, 360};

    draw3DAxes();
	DrawShadow(size,pl_source);
    draw3dcube(size);
	draw_A(start_pnt, size);


    return 0;

}
